# formulas que se pueden usar para la regresion
# no es un codigo que funciona, no tiene datos
from sklearn import linear_model

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = linear_model.LinearRegression()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)
# precision
precision = algoritmo.score(x_prueba, y_prueba)
# definir algoritmo
linear_model.LinearRegression()
# entrenar modelo
fit(x, y)
# predecir modelo
predict(x)
# conocer pendiente(a)
coef_
# conocer interseccion(b)
intercept_
# precision modelo
score(x)
