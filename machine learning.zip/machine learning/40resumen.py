# ventajas y desventajas de los algoritmos de clasificacion

# regresion logistica
# es el analisis de regresion apropiado para realizar cuando la variable dependiente es binaria
# usos:
# ordenar los resultados por probabilidad
# modelado de respuestas de marketing
# K vecinos mas cercanos
# es un algoritmo muy simples,facil de entender, versatil. esta basado en la similitud de caracteristicas
# usos:
# seguridad informatica(deteccion de intrusos)
# sistema de recomendacion
# problemas de correcion ortografica
# recuperacion de contenido de video
# maquinas vectores de soportes de clasificacion
# se basa en la construcccion de un hiperplano optimo en forma de superficie de decision...
# de modo que el margen de separacion entre las dos clases
# usos:
# clasificacion de texto e imagenes
# reconocimiento de escritura a mano
# NAIVE BAYES
# es un modelo probabilistico que se utiliza para las tareas de clasificacion
# usos:
# reconocimiento de rostros
# analisis de los sentimientos
# deteccion de spam
# clasificacion de textos
# ARBOLES DE DECISION CLASIFICACION
# dado un conjunto de datos se fabrican diagramas de construccion logicas,que sirven para...
# ...representar y categorizar una serie de conficiones que ocurren de forma sucesiva
# usos:
# diagnostico medica
# analisis de riesgo crediticio
# BOSQUES ALEATORIOS CLASIFICACION
# es una combinacion arboles de decision tal que cada arbol depende de los valores de unos vectores aleatorio ...
# ...probado independientemente y con la misma distribucion para cada uno de estos
# usos:
# para casi cualquier problema de machine learning
# bioinformatica
