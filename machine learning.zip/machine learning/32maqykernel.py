# maquinas vectores de soporte clasificacion
# ofrece una precision muy alta en comparacion con otros clasificadores como regresion logistica y los arboles de decision
# se utiliza una variedad de palicacion taloes como deteccion de rostros,intrusos,clasificacin de correos
# vectores de soporte: son los puntos de datos mas cercanos al hiperplano
# hiperplano:es un plano de decision que separa entre un conjunto de objetos
# margen:es un espacio entre las dos lineas en los puntos mas cercanos de la clase
# el objetivo principal es segregar el conjunto de datos de la mejor manera posible.
# la distancia entre los puntos mas cercanos se conoce como el margen
# genera hiperplanos que segreguen las clases de la mejor manera
# buscando el menor error de clasificacion
# seleccionar el hiperplano correcto con la maxima segregacion de los puntos de datos mas cercanos

# un kernel transforma un espacio de datos de entrada en la forma requerida
# resumen maquinas vectores de soporte
# ventajas: ofrecen una buuena precision y realizan predicciones mas rapidas, utiliza menos memoria, funciona bien con un claro margen de separacion
# desventajas: no son adeacuadas para grandes conjuntos de datos, funciona mal con clases superpuestas y sensible al tipo de nucleo utilizado
###########################################################################
###############################################################################
# KERNEL#
# los kernel deben su nombre al uso de las funciones de nucleo, que les permiten operar en un espacio de caracteristicas
# implicito y de alta dimension sin tener que calcular nunca las coordenadas de los datos en ese espacio
# la idea principal es mapear los datos a un espacio dimensional superior
# kernel ofrece una forma mas eficiente y menos costosa de transformar los datos en dimensiones superiores
# diferentes funciones de kernel:
# kernel lineal
# kernel polinomial
# kernel RBF (o gausseano):puede mapear un espacio de entrada en un espacio dimensional infinito
##########################################################################
###########################################################################
##maquinas vectores soporte clasificacion scikit learn
from sklearn.svm import SVC

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = SVC()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)

# definir algoritmo
SVC()
# predecir modelo
predict()
# entrenar modelo
fit(x, y)
