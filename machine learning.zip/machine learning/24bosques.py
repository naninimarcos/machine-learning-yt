# los bosques aleatorios es un algoritmo de machine learnig flexible y facil d usar
# crea un bosque y lo hace de alguna manera aleatorio
# crea multiples arboles de decision y los combina para obtener una prediccion mas precisa y estable
# busca la mejor caracteristica entre un subconjunto aleatorio de caracteristicas
# los bosques aleatorios evita el exceso de adaptacion la mayor parte del tiempo...
# creando subconjuntos aleatorios de las caracteristicas
# ventajas:
# algoritmo muy facil y util de usar, ya que los parametros predeterminados ...
# a menudo producen un buen resultado de prediccion
# si hay suficientes arboles en el bosque,el algoritmo no se adaptara al modelo, evitando el sobreajusste
# desventajas:
# una gran cantidad de arboles puede hacer que el algoritmo sea lento e ineficiente...
# para las predicciones en tiempo real
# es una herramienta de modelado predictivo y no una herramienta descriptiva
################################################################################################
from sklearn.ensemble import RandomForestRegressor

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = RandomForestRegressor()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)
#############################
# definir algoritmo
RandomForestRegressor()
# entrenar modelo
fit(x, y)
# predecir modelo
predict(x)
# precision modelo
score(x)