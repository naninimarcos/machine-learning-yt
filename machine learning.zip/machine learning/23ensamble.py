# ensamble de modelos
# metodos de ensamble de modelos
# si tenemos 4 pronosticos con la sig confianza (60,70,70,75) , en conjunto tendremos 99.92%
# combina predicciones de varios modelos,promedia errores idiosincraticos ...
# ...y produce mejores predicciones generales
# los mas utilizados son
# agregacion bootstrap o bagging (todo dato con seleccion mas)
# se prueban su modeles y luegos se unen
# boosting forma de entrenamiento secuencial.
# intenta dar mayor peso a las obs que estimo pobremente.
# luego las estimaciones son ponderadas segun su precision
