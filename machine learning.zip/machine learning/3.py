import pandas as pd
import numpy as np

data = np.array([["", "col1", "col2"], ["fila1", 11, 22], ["fila2", 33, 44]])
print(pd.DataFrame(data=data[1:, 1:], index=data[1:, 0], columns=data[0, 1:]))
