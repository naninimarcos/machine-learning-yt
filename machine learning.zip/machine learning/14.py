# regresion lineal , funcional
import numpy as np
from sklearn import datasets, linear_model

# sino es: import matplotlib.pyplot as plt
import matplotlib.pyplot as plt

#######################
# preparar la data
boston = datasets.load_boston()
print(boston)
print()
# verifico la informacion contenida en el dataset
print("informacion en el dataset:")
print(boston.keys())
# verifico las caracteristicas
print("caracteristicas del dataset:")
print(boston.DESCR)
# verifico la cantidad de datos que hay en el dataset
print("cantidad de datos")
print(boston.data.shape)
# verifico la informacion de las columnas
print("nombres columnas")
print(boston.feature_names)
#####################################
# preparamos para hacer la regresion
# en nuestro caso la columna 5
X = boston.data[:, np.newaxis, 5]
# defino los datos correspondientes a las etiquetas
y = boston.target
# graficamos los datos correspondientes
plt.scatter(X, y)
plt.xlabel("numero de habitaciones")
plt.ylabel("valor medio")
plt.show()
########## tenemos que separar datos de entrenamiento de la prueba

from sklearn.model_selection import train_test_split

# separo los datos de "train" en entrenamiento y prueba para pobrar los algoritmos
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
# defino el algoritmo a utilizar
lr = linear_model.LinearRegression()
# entreno el modelo
lr.fit(X_train, y_train)
# realizo una prediccion
y_pred = lr.predict(X_test)

# graficamos los datos junto con el modelo
plt.scatter(X_test, y_test)
plt.plot(X_test, y_pred, color="red", linewidth=3)
plt.title("regresion lineal simple")
plt.xlabel("numero de habitaciones")
plt.ylabel("valor medio")
plt.show()
#
print()
print("datos del modelo de regresion lineal simple")
print()
print("valor de la pendiente")
print(lr.coef_)
print()
print("valor de la interseccion")
print(lr.intercept_)
print()
print("la ecuacion del modelo es igual a:")
print("y =", lr.coef_, "x", lr.intercept_)

print()
print("precision del modelo:")
print(lr.score(X_train, y_train))
