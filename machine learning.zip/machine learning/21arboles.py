# algoritmo de arbol de decision regresion teoria:
# son una tecnica de predicion supervisado
# se divide el espacio de la caracteristica en varias regiones rectangulares
# Wm es la respuesta media en una region particulas
# Vm representa como se divide cada variables en un valor de umbral particular
# divide el espacio de caraceristicas p-dimensional, en m regiones muuamente distintas que...
# cubren completamente el subconjunto del espacio
# la division binaria recursiva aborda el problema comenzando en la parte sup. del arbol...
# y dividiendo el arbol en 2 ramas,lo que crea una particion de dos espacios
# el arbol de decision es propenso a sobreajuste
# para esto se puede limitar el crecimiento de un arbol de decision
# la poda del arbol implica probar el arbool originla contra versiones podadas de el
################################################################################################
#####scikit learn para arboles######
from sklearn.tree import DecisionTreeRegressor

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = DecisionTreeRegressor()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)
#############################
# definir algoritmo
DecisionTreeRegressor()
# entrenar modelo
fit(x, y)
# predecir modelo
predict(x)
# precision modelo
score(x)