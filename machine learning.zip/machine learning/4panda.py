import pandas as pd
import numpy as np

df = pd.DataFrame(np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]]))
print("dataframe")
print(df)
### forma de os datos
print("forma de los datos")
print(df.shape)
#####altura del dataframe
print("altura del dataframe")
print(df.index)
######
print("estadisticas del dataframe")
print(df.describe())
#####
print("medida de todas las columnas dataframe")
print(df.mean())
#######
print("correlacion del dataframe")
print(df.corr())
###### cuenta los datos del dataframe
print("conteo de datos del dataframe")
print(df.count())
###valor mas alto de cada columna
print("valor mas alto de la columna del dataframe")
print(df.max())
###### valor minimo de cada columna
print("valor minimo de cada columna")
print(df.min())
# mediana de cada colmna
print("mediana de la columna del dataframe")
print(df.median())
##ds
print("desviacion estandar")
print(df.std())
#### seleccionar un valor particular
print(df.iloc[0, :])
##verificar si hay datos nulos en el dataframe (falso para valores no perdidos)
print(df.isnull())
# suma de datos nulos en el dataframe
print(df.isnull().sum())