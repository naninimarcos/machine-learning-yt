# regresion logistica
# es un metodo de regresion para predecir clases biarias
# dicotomica significa que solo hay dos clases posibles
# la funcion logistica es tambien llamada fincion sigmoide
# la regresion logistica proporciona una salida discreta
# TIPOS DE REGRESION LOGISTICA
# regrecion logistica binaria: la var. objetivo tiene solo 2 resultados posibels
# reg. log. multinomial: la var. obj. tiene 3 o mas categorias nominales
# r.l.ordinal: la var. obj. tiene 3 o mas categorias ordinales#
#########################################################################
# PRACTICO#
from sklearn import datasets

dataset = datasets.load_breast_cancer()
print(dataset)
# entendimiento de la data
# verifico la info. contenida en el dataset
print("informacion en el dataset:")
print(dataset.keys())
print()
# describe
print("caracteristicas del dataset:")
print(dataset.DESCR)
# SELECCIONAMOS TODAS LAS COLUMNAS
x = dataset.data
# defino los datos correspondientes a las etiquetas
y = dataset.target
#
from sklearn.model_selection import train_test_split

# separo los datos de train en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
# se escalan todos los datos
from sklearn.preprocessing import StandardScaler

escalar = StandardScaler()
X_train = escalar.fit_transform(X_train)
X_test = escalar.transform(X_test)
# defino el algoritmo a utilizar
from sklearn.linear_model import LogisticRegression

algoritmo = LogisticRegression()
# entreno el modelo
algoritmo.fit(X_train, y_train)
# realizo una prediccion
y_pred = algoritmo.predict(X_test)
# verifico la matriz de confusion
from sklearn.metrics import confusion_matrix

matriz = confusion_matrix(y_test, y_pred)
print("matriz de confusion:")
print(matriz)
# calculo la presicion del modelo
from sklearn.metrics import precision_score

precision = precision_score(y_test, y_pred)
print("precision del modelo:")
print(precision)
# calculo la exactitud del modelo
from sklearn.metrics import accuracy_score

exactitud = accuracy_score(y_test, y_pred)
print("exactitud del modelo")
print(exactitud)
# calculo la sensibilidad del modelo
from sklearn.metrics import recall_score

sensibilidad = recall_score(y_test, y_pred)
print("sensibilidad del modelo")
print(sensibilidad)
# calculo el puntaje f1 del modelo
from sklearn.metrics import f1_score

puntajef1 = f1_score(y_test, y_pred)
print("puntaje f1 del modelo")
print(puntajef1)
# calculo la curva roc-auc del modelo
from sklearn.metrics import roc_auc_score

roc_auc = roc_auc_score(y_test, y_pred)
print("curva roc - auc del modelo:")
print(roc_auc)
