# teorico scikit
# es una libreria con numpy, pandas , scipy, matplotlib, ip[y] sympy
# en jupiter ya viene todo eso listo, sin necesidad de descargar
# muy importante para maching learning
##########################################################################
# erores de prediccion
# 1- de bias o sesgo
# 2- de varianza
# 3- irreducible (se lo conoce como ruido)
# 1 de bias, diferencia de lo esperado y el valor real del modelo... (residuo)
#### bajo bias sugiere menos suposiciones sobre la forma de la funcion obj
# 2 error de varianza...
# compensacion bias-varianza
# baja varianza y alto bias (regresion lineal)
# bajo bias y alta varianza(no lineales)
# para contruir un buen modelo, necesitamos encontrar un buen equilibrio entre el bias y la varianza
###########################################################################
# subajuste cuando un modelo no
# se ajusta a los datos bien
# (por pocos datos o haciendo lineal cuando es no lineal o viceversa)
# sobreajuste modela los datos de entrenamiento demasiado bien
# (llega a tener impacto negativo en datos nuevos)
# para mejorar el modelo hay que agregar datos relevantes
# tecnica de validacion cruzada (de 5 veces)
# deteccion temprana
# regularizacion
# por lo general se cae en el sobreajuste
############################################################################
## error en modelos de regresion
# error cuadratico medio (valores mas bajos indican un mejor ajuste)
# error absoluto medio  (todas las dif. ind se ponderan por igual en el promedio)
# r^2
## REGRESION LINEAL (es un metodo para machine learning basico)
# todo lo ya visto en estadistica 2 en la facultad
