# regresion multiple
import numpy as np
from sklearn import datasets, linear_model

import matplotlib.pyplot as plt

boston = datasets.load_boston()
print(boston)
print()
# verifico la informacion contenida en el dataset
print("informacion en el dataset:")
print(boston.keys())
# verifico las caracteristicas
print("caracteristicas del dataset:")
print(boston.DESCR)
# verifico la cantidad de datos que hay en el dataset
print("cantidad de datos")
print(boston.data.shape)
# verifico la informacion de las columnas
print("nombres columnas")
print(boston.feature_names)
#####################################
# preparamos para hacer la regresion multiple
# en nuestro caso la columna 5 y 8
X_multiple = boston.data[:, 5:8]
print(X_multiple)
# defino los datos correspondientes a las etiquetas
y_multiple = boston.target
######################
from sklearn.model_selection import train_test_split

# separo los datosde 'train' en entrenamiento y prueba para pronar los algoritmos
X_train, X_test, y_train, y_test = train_test_split(
    X_multiple, y_multiple, test_size=0.2
)
# defino el algoritmo a utilizar
lr_multiple = linear_model.LinearRegression()

# entreno el modelo
lr_multiple.fit(X_train, y_train)
# realizo una prediccion
Y_pred_multiple = lr_multiple.predict(X_test)
###############
print("datos del modelo de regresion lineal multiple")
print("valor de las pendientes")
print(lr_multiple.coef_)
print("valor de la interseccion")
print(lr_multiple.intercept_)
print("precision del modelo")
print(lr_multiple.score(X_train, y_train))
