# bosques aleatorias clasificacion-teoria
# un bosque esta compuesto de arboles. se dice que cuantos mas arboles tenga...
# ...mas robusto sera el bosque
# crea arboles de decision a partir de muestras de datos seleccionados al azar...
# obtiene predicciones de cada arbol y selecciona la mejor solucion mediante votacion
# los arboles de decision individuales se generan utilizando un indicador de seleccion...
# ... atributos (ganacia de informacion,relacion de ganancia,indice Gini)
# en un problema de clasificacion,cada arbol vota y se elige la clase mas popular como resultado final.
# es mas simple y mas potente en comparacion con otros algoritmo de clasificacion no lineal
# IMPORTANCIA DE LAS CARACTERISTICAS
# mide la importacia de las caracteristicas observando en que medida los nodos de los arboles, que...
# ...utilizan esas caracteristicas,reducen la impureza de todos los arboles del bosque
# ventajas:
# los bosques aleatorios se consideran un metodo muy preciso y robusto debido al numero de arboles de ...
# ...decision que participan en el proceso
# no sufre el problema del sobreajuste. la razon principal es que toma el promedio de todas las predicciones
# esto anula los sesgos
# tambien pueden manejar los valores que faltan
# puede obtener la importacia relativa de las caracteristicas, lo que ayuda a seleccionar las...
# caracteristicas mas importantes para el clasificador
# desventajas:
# sonn lentos en generar predicciones porque tienen multiples arboles de decision
# el modelo es dificil de interpretar en comparacion con un arbol de decision
###############################################################################################
#########################################################################################
# scikit learn
from sklearn.ensemble import RandomForestClassifier

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = RandomForestClassifier()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)

# definir algoritmo
RandomForestClassifier()
# predecir modelo
predict()
# entrenar modelo
fit(x, y)
