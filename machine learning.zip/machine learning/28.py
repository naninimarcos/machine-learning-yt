# conjunto de datos desbalanceado.
# los datos desbalanceado siempre plantea un p`roblema para los trabajos de machine learning
# las clases minoritarias son dejadas de cuenta, capaz con 99% de precision general
# ejemplo con los fraudes bancarios, donde se tiene 99% o mas de precision pero la parte no precisa
# significa perdidas importantes
# metodos:
# remuestreo del conjunto de datos
# la idea principal de las clases de muestreo es aumentar las muestras de la clase minoritaria o disminuir las muestras de la clase mayoritaria.
# esto se hace para obtener un saldo justo en el numero de instancias para ambas clases

# submuestreo aleatorio: al eliminar aleatoriamente instancias de la clase de la mayoria de un conjunto de datos y la asigna
# a la clase minoritaria, sin necesidad de rellenar el vacion creado en la clase de mayoria
# ventaja: puede ayudar a mejorar el tiempo de ejecucion del modelo y resolver los problemas de memoria
# desventajas:puede descartar informacion util sobre los datos en si mismos que podria ser necesaria para crear clasificadores basados en reglas
# la muestra elegida puede ser una muestra sesgada, y no sera una representacion precisa
# sobremuestreo del conjunto de datos:aumenta las instancias correspondientes a las clase minoritaria
# ... replicandolas hasta un grado constante.
# ventajas:este metodo no conduce a la perdida de informacion
# desventajas: aumenta la provavilidad de un exceso de equipamiento ya que replica los eventos de la clase minoritaria
# considera aplicar un sobre-muestreo cuando no tengas muchos datos
