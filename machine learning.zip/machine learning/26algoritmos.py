# ventajas y desventajas algoritmos de regresion
# regresion lineal
# entrenar la mejor linea a traves de todos los puntos de datos
# ventajas:es facil de entender y explicar y es facil de modelar y es menos propenso al sobreajuste
# desventajas: no se puede modelar relaciones complejas, no captura relaciones no lineales sin transformacion al inicio
# vectores de soporte regresion
# se basa en la construccion de un hiperplano optimo
# ventaja:se puede modelar relaciones complejas,no lineales, robusto al ruido
# desventaja: con muchos datos toma tiempo entrenar
# arboles de decision regresion
# dado un conjunto de datos se fabrican diagramas de construccion logicas
# ventajas:es preciso y es excelente para relaciones complejas no lineales
# desventajas:son dificiles de interpretas,esposible la duplicacion dentro del mismo sub-arbol
# bosques aleatorios regresion
# es una combinacion de arboles de decision
# ventajas:puede trabajar en paralelo, rara vez se sobreajusta,tiene excelentes resultados
# desventajas: dificil de interpretar,mas debil en la regresion al estimar valores en los extremos de la distribucion
