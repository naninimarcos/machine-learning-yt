#################### VIDEO 33 ############################################
# #matriz de confunsion (algo asi a la tabla de alfa y b, con niveles de confianza y potencia)
# es una de las metricas mas intuitivas y sencillas que se utiliza para encontrar la precision y exactitud del modelo.
# se utiliza para el problema de clasificacion donde la salida puede ser de dos o mas tipos de clases.

###################### VIDEO 34 ##############################################################
# EVALUANDO EL ERROR EN LOS MODELOS DE CLASIFICACION#
# Exactitud--> numero de predicciones correctas realizadas por el modelo por el numero total de registros
# precision-->evaluamos nuestros datos por su desempeño de predicciones "positivas"
# sensibilidad(recall)-->se calcula como el numero de predicciones positivas correctas...
# divido por el numero total de positivos
# especificidad--> lo contrario a la sensibilidad
# tasa negativa verdadera,se calcula como el numero de predicciones
# negativas correctas dividido por el numero total de negativos
# puntaje de F1-->promedio ponderado de precision y sensibilidad
###################### VIDEO 35 #######################################################
# roc:caracteristicas de funcionamiento del receptos
# auc:area bajo la curva
# curva roc nos dice que tan bueno puede distinguir el modelo entre 2 cosas.
# mejores modelos pueden distinguir con precision entre los dos, mientras que un...
# modelo pobre tendra dificultades para distinguir entre los 2
# hay verdaderos positivos,verdaderos negativos,falso positivos y falso negativos
# curva  ROC-AUC
# AUC--> es el area bajo la curva roc
# este puntaje nos da una buena idea de que tan bien funciona el modelo
# cuando dos distribuciones se superponen,introducimos errores. dependiendo del ...
# ... umbral, podemos minimizarlos o maximizarlos
########################### VIDEO 36 #############################
# matriz de confucion: tabla que describe el desempeño de un modelo de clasificacion en un conjunto de datos ...
# ... de prueba cuos valores verdaderos son conocidos. esta matriz es altamente interpretativa
from sklearn.metrics import confusion_matrix

matriz = confusion_matrix(y_test, y_pred)
print(matriz)
# exactitud: es la relacion entre las predicciones corretas y el numero total de precdicciones.
# ... con que frecuencia es correcto el clasificador
from sklearn.metrics import accuracy_score

exactitud = accuracy_score(y_test, y_pred)
print(exactitud)
# precision: es la relacion entre las predicciones correctas y el numero total de predicciones
# correctas previstas. esto mide la precision del clasificador a la hora de predecir casos positivos
from sklearn.metrics import precision_score

precision = precision_score(y_test, y_pred)
print(precision)
# sensibilidad:es la relacion entre las predicciones positivas correctas y el numero total de predicciones positivas
# o mas simplemente,cuan sensile es el clasificador para detectar instancias positivas. esto tambien se
# conoce como la tasa verdadera positiva
from sklearn.metrics import recall_score

sensibilidad = recall_score(y_test, y_pred)
print(sensibilidad)
# puntaje de F1:es la medida armonica de la memoria y la precision, con una puntuacion mas alta como mejor modelo
from sklearn.metrics import f1_score

puntaje = f1_score(y_test, y_pred)
print(puntaje)
