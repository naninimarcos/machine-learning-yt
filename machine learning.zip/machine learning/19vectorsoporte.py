# vectores de soperte regresion
# la salidad es un numero real, se vuelve muy dificil predecir la informarcion disponible
# minimizar el error
# individualizar el hiperplano que maximiza el margen
# se tolera parte del error
# lo primero es obtener un hiperplano (y=wx+b)
# se le pone lineas paralelas que seran vectores de apoyo o soporte
# no es necesario que cubra todos los datos
# la distancia entre una banda y un elemente fuera de las bandas se denomina epsilon
# w es la magnitud del vector
# c es una constante >0
# epsilo son las variables que controlan el erro rcometido por la...
# ...funcion de regresion al aproximar a las bandas
# el rendimiento del algoritmo de vectores de soporte regresion...
# depende de una buena conf. de los parametros c y de los del Kernel
################################################################################
##################################################################################
from sklearn.svm import SVR

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = SVR()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)
# definir algoritmo
SVR()
# entrenar modelo
fit(x, y)
# predecir modelo
predict(x)
# precision (despues de usar el modelo)
precision = algoritmo.score(x_prueba, y_prueba)
