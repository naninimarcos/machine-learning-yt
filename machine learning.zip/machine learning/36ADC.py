# arboles de decision clasificacion teoria
# puede ser facilmente visible para entender que sucede
# estructura igual a un nodo o diagrama de flujo
# la medida d seleccion de atributos es una heuristica para seleccionar el ...
# ...criterio de division que divide los datos de la mejor manera posible
# esta medida proporciona un rango a cada caracteristica,explicando el conjunto de datos dado
# el atributo de mejor puntuacion se seleccionara como atributo de division
# GANANCIA DE INFORMACION
# cuando usamos un nodo en un arbol de decision para particionar las instancias de formacion...
# ...en subconjuntos mas pequeños, la entropia cambia. la ganancia de informacion es una...
# ...medida de este cambio en la entropia
# pasos:
# comenzar con todas las instancias de formacion asociadas al nodo raiz
# utilizar la ganancia de informacion para elegir que atriuto etiquetar cada nodo con cual
# construir cada subarbol en el subconjunto de instancias de capacitacion que se clasificarian
# INDICE DE GINI
# es una metrica para medir la frecuencia con la que un elemento elegido al azar...
# ... seria identificado incorrectamento.Esto significa que se debe preferir un...
# ... atributo con un indice de Gini mas bajo
# ventaja:facil de interpretar y visualizar; requiere menos prepocesamiento
# desventajas:datos sensibles al ruido, pequeña variacion puede dar lugar a un arbol de decision diferente
# estan sesgados con un conjunto de datos de desequilibrio
###ARBOLES DE DECISION CLASIFICACION- scikit learn
# entra dentro de la categoria de  aprendizaje supervisado
from sklearn.tree import DecisionTreeClassifier

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = DecisionTreeClassifier()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)

# definir algoritmo
DecisionTreeClassifier()
# predecir modelo
predict()
# entrenar modelo
fit(x, y)
