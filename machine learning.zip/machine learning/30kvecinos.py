# k vecinos mas cercanos
# no parametrico, significa que no hace suposiciones explicitas sobre la forma funcional de los datos
# memoriza las instancias de formacion que posteriormente se utilizan como "conocimiento" para la fase de prediccon
# la fase de formacion minima de KNN se realiza tanto a un coste de memoria,ya que debemos almacenar un conjunto de datos potencialmente enorme
# el numero de vecinos(k) es un hiperparametro que se debe elegir en el momento de la construccion del modelo
# no existe un numero optimo de vecinos que se adapte a todo tipo de conjuntos de datos, cada conjunto de datos tiene sus propios requisitos
# una pequeña cantidad de vecinos tendran un bajo sesgo, pero una alta varianza, y un gran numero de vecinos tendran una varianza mas baja ---
# --- pero un sesgo mas alto
# se recomienda elegir un numero impar si el numero de clases es par
#################################################################################
########################################################################################
# K VECINOS MAS CERCANOS- SCIKIT LEARN###
from sklearn.neighbors import KNeighborsClassifier

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = KNeighborsClassifier()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)

# definir algoritmo
KNeighborsClassifier()
# predecir modelo
predict()
# entrenar modelo
fit(x, y)
