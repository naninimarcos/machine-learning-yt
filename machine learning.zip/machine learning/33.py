# maquinas vectores soporte clasificacion-practica
from sklearn import datasets

dataset = datasets.load_breast_cancer()
print(dataset)
# entendimiento de la data
# verifico la info. contenida en el dataset
print("informacion en el dataset:")
print(dataset.keys())
print()
# describe
print("caracteristicas del dataset:")
print(dataset.DESCR)
# SELECCIONAMOS TODAS LAS COLUMNAS
x = dataset.data
# defino los datos correspondientes a las etiquetas
y = dataset.target
###########################################################################
################################################################################
from sklearn.model_selection import train_test_split

# separo los datos de train en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2)
# defino el algoritmo a utilizar
from sklearn.svm import SVC

algoritmo = SVC(kernel="linear")
# entreno el modelo
algoritmo.fit(X_train, y_train)
# prediccion
y_pred = algoritmo.predict(X_test)
# verifico la matriz de confusion
from sklearn.metrics import confusion_matrix

matriz = confusion_matrix(y_test, y_pred)
print("matriz de confusion:")
print(matriz)
# calculo la precision del modelo
from sklearn.metrics import precision_score

precision = precision_score(y_test, y_pred)
print("precision del modelo:")
print(precision)
