# BOSQUES ALEATORIOS REGRESION practica #30
import numpy as np
from sklearn import datasets
import matplotlib.pyplot as plt

boston = datasets.load_boston()
print(boston)
print()
# verifico la informacion contenida en el dataset
print("informacion en el dataset:")
print(boston.keys())
# verifico las caracteristicas
print("caracteristicas del dataset:")
print(boston.DESCR)
# verifico la cantidad de datos que hay en el dataset
print("cantidad de datos")
print(boston.data.shape)
# verifico la informacion de las columnas
print("nombres columnas")
print(boston.feature_names)
###############################################################################################
# preparar la data bosques aleatorios regresion
# selecionamos solamente la columna 6 del dataset
X_bar = boston.data[:, np.newaxis, 5]
# defino los datos correspondientes  a las etiquetas
y_bar = boston.target
###graficamos
plt.scatter(X_bar, y_bar)
plt.show()
###################################################
###########implementacion de bosques aleatorios regrecion
from sklearn.model_selection import train_test_split

# separo los datos de 'train' en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_bar, y_bar, test_size=0.2)
############################################
from sklearn.ensemble import RandomForestRegressor

# defino el algoritmo a utilizar
# n_estimators es la cantidad de arboles, max_depth es la profundidas (creo)
bar = RandomForestRegressor(n_estimators=300, max_depth=8)

# entreno el modelo
bar.fit(X_train, y_train)
# realizo una prediccion
Y_pred = bar.predict(X_test)
####################################################
# graficamos los datos de prueba junto con la prediccion
x_grid = np.arange(min(X_test), max(X_test), 0.1)
x_grid = x_grid.reshape(len(x_grid), 1)
plt.scatter(X_test, y_test)
plt.plot(x_grid, bar.predict(x_grid), color="red", linewidth=3)
plt.show()
###############################################################################
print("datos del modelo bosques aleatorios regresion")
print()
print("precision del modelo")
print(bar.score(X_train, y_train))
