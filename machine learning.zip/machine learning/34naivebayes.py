# naive bayes
# es uno de los algoritmos mas simples y poderosos para la clasificacion basado en el teorema de bayes
# con una suposicion de independencia entre los predictores
# asume que el efecto de una caraceristica particular en una clase es independiente de otras caracteristicas
# ventajas: es facil y rapido de predecir la clase de conjunto de datos de prueba
# funciona bien en la prediccion multiclase
# cuando se mantiene la suposicion de independenciaa, un clasificador NAIVE BAYES...
# ...funciona mejor en comparacion con otros modeles
# desventajas: si la variable cateforica tiene na categoria en el conjunto de datos de prueba, que no se observo en el ...
# ... conjunto de datos de entrenamiento, el modelo asignara una probabilidad de 0 y no podra hacer una prediccion
# asumcion de predictores independientes.en la vida real es casi imposible que obtengamos conjunto de predictorres completamente independientes
###########################################################################################################################
# #####################################################################################################################################
# NAIVE BAYES SCKIT LEARN
from sklearn.naive_bayes import GaussianNB

x_entrenamiento = variablesIndependientes_entrenamiento
y_entrenamiento = variablesDependientes_entrenamiento
x_prueba = variablesIndependientes_prueba
y_prueba = variablesDependientes_prueba

algoritmo = GaussianNB()
algoritmo.fit(x_entrenamiento, y_entrenamiento)
algoritmo.predict(x_prueba)

# definir algoritmo
GaussianNB()
# predecir modelo
predict()
# entrenar modelo
fit(x, y)
