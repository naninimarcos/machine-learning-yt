# regresion polinomica
import numpy as np
from sklearn import datasets, linear_model
import matplotlib.pyplot as plt

boston = datasets.load_boston()
print(boston)
print()
# verifico la informacion contenida en el dataset
print("informacion en el dataset:")
print(boston.keys())
# verifico las caracteristicas
print("caracteristicas del dataset:")
print(boston.DESCR)
# verifico la cantidad de datos que hay en el dataset
print("cantidad de datos")
print(boston.data.shape)
# verifico la informacion de las columnas
print("nombres columnas")
print(boston.feature_names)
##############################################
##############################################
# preparar la data regresion polinomial
# selecionamos solamente la columna 6 del dataset
X_p = boston.data[:, np.newaxis, 5]
# defino los datos correspondientes a las etiquetas
y_p = boston.target

### graficamos los datos correspondientes
plt.scatter(X_p, y_p)
plt.show()
############################implementacion de regresion polinomial
from sklearn.model_selection import train_test_split

# separo los datos de'train' en entrenamientos y pruebas
X_train_p, X_test_p, y_train_p, y_test_p = train_test_split(X_p, y_p, test_size=0.2)
from sklearn.preprocessing import PolynomialFeatures

# se define el grado del polinomio
poli_reg = PolynomialFeatures(degree=2)
# se transforma las caracteristicas existentess en caracteristicas de mayor grado
X_train_poli = poli_reg.fit_transform(X_train_p)
X_test_poli = poli_reg.fit_transform(X_test_p)
# defino el algoritmo a utilizar
pr = linear_model.LinearRegression()

# entreno el modelo
pr.fit(X_train_poli, y_train_p)
# realizo una prediccion
Y_pred_pr = pr.predict(X_test_poli)
# graficamos los datos junto con el modelo
plt.scatter(X_test_p, y_test_p)
plt.plot(X_test_p, Y_pred_pr, color="red", linewidth=3)
plt.show()
############################
print()
print("datos del modelos d regresion polinomial")
print()
print("valor de la pendiente")
print(pr.coef_)
print("valor de la intercepcion")
print(pr.intercept_)
print("precision del modelo:")
print(pr.score(X_train_poli, y_train_p))
