import matplotlib.pyplot as plt

x1 = [3, 4, 5, 6]
y1 = [5, 6, 3, 4]
x2 = [2, 5, 8]
y2 = [3, 4, 3]

plt.plot(x1, y1, color="blue", linewidth=3, label="linea1")
plt.plot(x2, y2, color="green", linewidth=3, label="linea2")

plt.title("diagrama de lineas")
plt.ylabel("eje y")
plt.xlabel("eje x")

plt.legend()
plt.grid()
plt.show()