# parte practica de vectores soporte regresion
import numpy as np
from sklearn import datasets, linear_model
import matplotlib.pyplot as plt

boston = datasets.load_boston()
print(boston)
print()
# verifico la informacion contenida en el dataset
print("informacion en el dataset:")
print(boston.keys())
# verifico las caracteristicas
print("caracteristicas del dataset:")
print(boston.DESCR)
# verifico la cantidad de datos que hay en el dataset
print("cantidad de datos")
print(boston.data.shape)
# verifico la informacion de las columnas
print("nombres columnas")
print(boston.feature_names)
######################################################## nueva parte
# preparar la data vectores de soporte regresion
# seleccionamos solamente la columna 6
X_svr = boston.data[:, np.newaxis, 5]
# defino los datos correspondientes a las etiquetas
y_svr = boston.target
# graficamos los datos
plt.scatter(X_svr, y_svr)
plt.show()
######IMPLEMENTACION DE VECTORES DE SOPORTE REGRESION#####
from sklearn.model_selection import train_test_split

# separo los datos de 'train' en entrenamiento y prueba
X_train, X_test, y_train, y_test = train_test_split(X_svr, y_svr, test_size=0.2)

from sklearn.svm import SVR

# defino el algoritmo a utilizar
# hay que definir como linear, sino ponemos nada esta conf. para no lineales
svr = SVR(kernel="linear", C=1.0, epsilon=0.2)
# entreno el modelo
svr.fit(X_train, y_train)
# realizo una prediccion
Y_pred = svr.predict(X_test)
##########
plt.scatter(X_test, y_test)
plt.plot(X_test, Y_pred, color="red", linewidth=3)
plt.show()
##########################################
print()
print("datos del modelo vectores de soporte regresion")
print()

print("precision del modelo")
print(svr.score(X_train, y_train))
