# toca regresion polinomial teoria #19
# extiende el modelo lineal al agregar predictores adicionales
# obtenidos al elevar cada uno de los predictores originales a una potencia
# regresion polinomial (y=a1x1+a2x^2+b)
# tiene una tendencia a ajustarse drasticamente, incluso en un conjunto de datos unidimensionales
# los polinomios sup. pueden terminar produciendo saltos extraños
# esta regresion es ,muy similar a la lineal, con una ligera desviacion en la forma
