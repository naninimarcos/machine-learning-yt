import numpy as np

array = np.array([[1, 2, 3, 4], [5, 6, 7, 8]], dtype=np.int64)
print(array)