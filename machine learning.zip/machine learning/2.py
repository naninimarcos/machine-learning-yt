import numpy as np

a = np.array([(8, 9, 10), (11, 12, 13)])
print(a)
a = a.reshape(3, 2)
print(a)