# metodo de seleccion de caracteristicas
# conjutos de datos muy grandes
# puede ocasionar que las caracterisiticas adicionales actuen como ruido
# el modelo tarda mas en entrenarse
# asignacion de recursos innecesarios para estar caracteristicas
# seleccion de caracteristicas
# para mejorar el predictor y que sea mas rapido y rentable
# metodos de filtros (no elimina la colinealidad)
# paso de pre seleccionamiento
# se clasifican segun su correlacion
# pearson para caracteristicas continuo y predicion continuo
# anova para categorico para caracteristicas categoricas y predicion continuo
# LDA(similar a anova) para caracteristicas continuas y predicion categorica
# chi-cuadrado para continuo para caracteristicas categoricas y predicion categorica
# metodos de envoltura(metodo de machine learnig,pero lento)
# selecciona el mejor subconjunto
# seleccion hacia delante:es un metodo iterativo, que comienza sin caracteristica
# eliminacion hacia atras: se elimina caracteristicas hasta que se mejora
# eliminacion de caracteristicas recursivas:clasifica las caracteristicas segun su orden de eliminacion
