import matplotlib.pyplot as plt

a = [3, 4, 5, 6]
b = [5, 6, 3, 4]
plt.plot(a, b, color="blue", linewidth=3, label="linea")
plt.legend()
plt.show()